function HitungLuasKeliling() {
    var sisi = parseInt(document.getElementById("sisi").value);
    var luas = sisi * sisi;
    var keliling = 4 * sisi;
    document.getElementById("luas").value = luas;
    document.getElementById("keliling").value = keliling;
}